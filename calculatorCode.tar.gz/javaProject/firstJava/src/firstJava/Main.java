package firstJava; 
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.time.*;

public class Main {

	//ITALIAN SCRIPT
	public static void main(String[] args) {
		System.out.println("Benvenuto nella calcolatrice!");
		
		//first input
		Scanner scanner = new Scanner(System.in);
		System.out.println("Scrivi il primo numero: ");
		int numero1= scanner.nextInt();
		scanner.nextLine();
		System.out.println("Scrivi il secondo numero: ");
		int numero2= scanner.nextInt();
		scanner.nextLine();
		
		//risultati
		int x = numero1+numero2;
		int y =  numero1 - numero2;
		System.out.println("Addizione :"+ x);
		System.out.println("Moltiplicazione :"+ numero1 * numero2);
		System.out.println("Divisione :"+ numero1 / numero2);
		System.out.println("Sottrazione :"+ y);
		LocalDate h = LocalDate.now();
		
		//save in file
		try {
			FileWriter writer = new FileWriter("Thank.md");
			writer.write("###Grazie per aver usato lo script!\n"+h);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
 
	} 

}


//-KONORY
